import java.lang.Exception;

public class VendingMachineException extends Exception {
    String in;
    public static final long serialVersionUID = 1L;
    public VendingMachineException(String in) {
        this.in = in;
        System.out.println(in);
    }
}